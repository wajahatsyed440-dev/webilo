"use strict";

// Public/publishable key only. Never put a Supabase service-role key in browser code.
const SUPABASE_URL = "https://xneescrrzpzywkleaefw.supabase.co";
const SUPABASE_KEY = "sb_publishable_5Fx11_BjfQfAW8VGoI43cA_UypV236-";

const $ = id => document.getElementById(id);
let db, session, projects = [], currentProject = null, projectDoc = null;
let isSignup = false, saving = false, activePath = "index.html", toastTimer;

const starterHTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Webilo website</title>
<style>
body{font-family:system-ui,sans-serif;background:#f5f3ff;color:#25213b;display:grid;place-items:center;min-height:100vh;margin:0}
main{max-width:650px;margin:24px;padding:40px;background:white;border-radius:24px;box-shadow:0 20px 70px #29205018}
h1{color:#7158e8}a{color:#7158e8}
</style>
</head>
<body><main><h1>Welcome to my website!</h1><p>Build something great with Webilo.</p><a href="https://example.com">A sample link</a></main></body>
</html>`;

function showOnly(page) {
  ["authPage","appPage","editorPage"].forEach(id => $(id).classList.toggle("hidden", id !== page));
}
function message(id, text, type="") {
  const el=$(id); el.textContent=text; el.className="message"+(type?" "+type:"");
}
function toast(text) {
  const el=$("toast"); el.textContent=text; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2800);
}
function errorText(err) {
  const m=err?.message || String(err || "Unknown error"), s=m.toLowerCase();
  if(s.includes("invalid login credentials")) return "Incorrect email or password. New here? Create an account first.";
  if(s.includes("email not confirmed")) return "Confirm your email using the link Supabase sent you, then sign in.";
  if(s.includes("user already registered")) return "This email already has an account. Try signing in.";
  if(s.includes("failed to fetch")||s.includes("networkerror")) return "Could not reach Supabase. Check your internet connection and project URL.";
  if(s.includes("row-level security")||s.includes("permission denied")) return "Supabase blocked this request. Check your table name and RLS policies.";
  if(s.includes("relation")&&s.includes("does not exist")) return "Table webilo_projects is missing. Run the SQL setup in Supabase.";
  if(s.includes("provider is not enabled")||s.includes("unsupported provider")) return "Google provider is not enabled in Supabase Authentication settings.";
  if(s.includes("redirect")||s.includes("oauth")) return "Google OAuth redirect configuration needs checking in Supabase.";
  return m;
}
function slugify(v) {
  return v.toLowerCase().trim().normalize("NFKD").replace(/[\u0300-\u036f]/g,"")
    .replace(/[^a-z0-9-]+/g,"-").replace(/-+/g,"-").replace(/^-|-$/g,"").slice(0,50)||"my-website";
}
function el(tag, cls, text) {
  const n=document.createElement(tag); if(cls)n.className=cls; if(text!==undefined)n.textContent=text; return n;
}
function setAuthMode(signup) {
  isSignup=signup;
  $("authTitle").textContent=signup?"Create your account.":"Welcome back.";
  $("authSubtitle").textContent=signup?"Sign up to start building websites.":"Sign in to open your workspace.";
  $("authSubmit").textContent=signup?"Create account":"Sign in";
  $("switchText").textContent=signup?"Already have an account?":"New to Webilo?";
  $("switchAuth").textContent=signup?"Sign in":"Create account";
  $("password").autocomplete=signup?"new-password":"current-password";
  message("authMessage","");
}
async function submitAuth(e) {
  e.preventDefault(); const btn=$("authSubmit");
  btn.disabled=true; message("authMessage",isSignup?"Creating account…":"Signing in…");
  try {
    const email=$("email").value.trim(), password=$("password").value;
    if(isSignup) {
      const {data,error}=await db.auth.signUp({email,password}); if(error)throw error;
      if(data.session) {session=data.session; await showWorkspace();}
      else message("authMessage","Account created. Check your email for a confirmation link, then sign in.","success");
    } else {
      const {data,error}=await db.auth.signInWithPassword({email,password}); if(error)throw error;
      session=data.session; await showWorkspace();
    }
  } catch(err) { message("authMessage",errorText(err),"error"); }
  finally {btn.disabled=false;}
}
async function googleSignIn() {
  try {
    message("authMessage","Opening Google sign-in…");
    const redirectTo=window.location.origin+window.location.pathname;
    const {error}=await db.auth.signInWithOAuth({provider:"google",options:{redirectTo}});
    if(error)throw error;
  } catch(err) {message("authMessage",errorText(err),"error");}
}
async function logout() {
  const {error}=await db.auth.signOut();
  if(error){message("appMessage",errorText(error),"error");return;}
  session=null;currentProject=null;projectDoc=null;projects=[];showOnly("authPage");setAuthMode(false);
}
async function showWorkspace() {
  if(!session?.user)return;
  $("userEmail").textContent=session.user.email||"Signed in";
  $("userName").textContent=session.user.user_metadata?.full_name||session.user.user_metadata?.name||"Webilo member";
  $("avatar").textContent=($("userName").textContent[0]||"W").toUpperCase();
  showOnly("appPage"); await loadProjects();
}
async function loadProjects() {
  if(!session?.user)return;
  message("appMessage","Loading projects…");$("projectGrid").replaceChildren();
  try {
    const {data,error}=await db.from("webilo_projects")
      .select("id,owner_id,name,slug,html,created_at,updated_at")
      .order("updated_at",{ascending:false});
    if(error)throw error;
    projects=data||[];renderProjects();
    message("appMessage",projects.length?`${projects.length} cloud project(s) loaded.`:"No projects yet. Create your first website.","success");
  } catch(err){message("appMessage",errorText(err),"error");}
}
function decodeDoc(raw) {
  try {
    const parsed=JSON.parse(raw||"");
    if(parsed && parsed.version===1 && Array.isArray(parsed.files)) {
      if(!parsed.logo) parsed.logo="";
      if(!parsed.domain) parsed.domain="webilo.com";
      if(!parsed.published) parsed.published=false;
      if(!parsed.publishSlug) parsed.publishSlug="";
      return parsed;
    }
  } catch {}
  // Migrate the previous version's plain HTML into the new file structure.
  return {version:1,files:[{path:"index.html",content:raw||starterHTML}],logo:"",domain:"webilo.com",published:false,publishSlug:""};
}
function encodeDoc() { return JSON.stringify(projectDoc); }
function renderProjects() {
  const grid=$("projectGrid");grid.replaceChildren();
  if(!projects.length) {
    const card=el("article","project-card"), icon=el("div","project-icon","W."), title=el("h3","","Your first website");
    const p=el("p","","Create a project, add files and publish details.");
    const btn=el("button","button primary full","Create website");btn.type="button";btn.addEventListener("click",createProject);
    card.append(icon,title,p,btn);grid.append(card);return;
  }
  projects.forEach(p=>{
    const card=el("article","project-card"), icon=el("div","project-icon");
    const doc=decodeDoc(p.html);
    if(doc.logo){const img=el("img");img.src=doc.logo;img.alt="";icon.append(img);}else icon.textContent="W.";
    const title=el("h3","",p.name), addr=el("p","",doc.published?`Publish details saved · ${doc.publishSlug||p.slug}.${doc.domain}`:`/${p.slug}`);
    const updated=el("p","","Updated "+new Date(p.updated_at||p.created_at).toLocaleString());
    const actions=el("div","card-actions"), edit=el("button","button primary","Open"), del=el("button","button secondary","Delete");
    edit.type=del.type="button";edit.addEventListener("click",()=>openProject(p.id));del.addEventListener("click",()=>deleteProject(p.id));
    actions.append(edit,del);card.append(icon,title,addr,updated,actions);grid.append(card);
  });
}
async function createProject() {
  if(!session?.user)return;
  const name="My new website", slug=slugify(name)+"-"+Math.random().toString(36).slice(2,6);
  const doc={version:1,files:[{path:"index.html",content:starterHTML}],logo:"",domain:"webilo.com",published:false,publishSlug:""};
  message("appMessage","Creating project…");
  try {
    const {data,error}=await db.from("webilo_projects").insert({
      owner_id:session.user.id,name,slug,html:JSON.stringify(doc)
    }).select("id,owner_id,name,slug,html,created_at,updated_at").single();
    if(error)throw error;projects.unshift(data);renderProjects();openProject(data.id);
  } catch(err){message("appMessage",errorText(err),"error");}
}
function ensureDocFiles() {
  if(!projectDoc.files.some(f=>f.path==="index.html")) projectDoc.files.unshift({path:"index.html",content:starterHTML});
  projectDoc.files.sort((a,b)=>a.path.localeCompare(b.path));
}
function openProject(id) {
  const p=projects.find(x=>x.id===id);if(!p)return;
  currentProject={...p};projectDoc=decodeDoc(p.html);ensureDocFiles();
  $("editorProjectName").textContent=p.name;$("projectName").value=p.name;
  $("projectSlug").value=projectDoc.publishSlug||p.slug;
  $("domainChoice").value=projectDoc.domain||"webilo.com";
  showLogo();renderFileTree();
  activePath=projectDoc.files.some(f=>f.path==="index.html")?"index.html":projectDoc.files[0].path;
  selectFile(activePath);refreshPreview();$("saveStatus").textContent="Loaded from cloud";
  message("editorMessage","");showOnly("editorPage");
}
function currentFile() {return projectDoc?.files.find(f=>f.path===activePath);}
function renderFileTree() {
  const tree=$("fileTree");tree.replaceChildren();
  const folders=new Set();
  projectDoc.files.forEach(f=>{
    const parts=f.path.split("/");
    for(let i=1;i<parts.length;i++)folders.add(parts.slice(0,i).join("/"));
  });
  const paths=[...folders].map(path=>({path,folder:true})).concat(projectDoc.files.map(f=>({path:f.path,folder:false})));
  paths.sort((a,b)=>a.path.localeCompare(b.path)||Number(b.folder)-Number(a.folder));
  paths.forEach(item=>{
    const row=el("div","tree-item"+(item.folder?" folder":"")+(item.path===activePath?" selected":""));
    const label=el("span","",item.folder?"▸":"");label.style.flexShrink="0";
    const name=el("span","tree-name",(item.folder?"":"")+(item.folder?"":item.path.split("/").pop()));
    if(item.folder) name.textContent=item.path.split("/").pop()+"/";
    row.append(label,name);
    if(!item.folder) {
      row.title=item.path;row.addEventListener("click",()=>selectFile(item.path));
      const del=el("button","tree-delete","×");del.type="button";del.title="Delete file";
      del.addEventListener("click",e=>{e.stopPropagation();deleteFile(item.path);});row.append(del);
    } else {row.title=item.path;row.style.paddingLeft=(8+item.path.split("/").length*7)+"px";}
    tree.append(row);
  });
}
function selectFile(path) {
  const f=projectDoc.files.find(x=>x.path===path);if(!f)return;
  activePath=path;$("activeFileLabel").textContent=path;$("fileEditor").value=f.content;
  renderFileTree();
}
function markDirty() {$("saveStatus").textContent="Unsaved changes";}
function normalizePath(path) {
  return path.replace(/\\/g,"/").split("/").map(s=>s.trim()).filter(s=>s&&s!=="."&&s!=="..").join("/");
}
function addFile(path,content="") {
  path=normalizePath(path);
  if(!path||path.endsWith("/"))throw new Error("Enter a file name, such as pages/about.html.");
  if(projectDoc.files.some(f=>f.path===path))throw new Error("A file with that path already exists.");
  projectDoc.files.push({path,content});projectDoc.files.sort((a,b)=>a.path.localeCompare(b.path));
  activePath=path;selectFile(path);markDirty();return path;
}
function createFile() {
  const path=prompt("File path (you can include folders), e.g. css/style.css","about.html");
  if(path===null)return;
  try{addFile(path,"");renderFileTree();toast("File created.");}
  catch(err){alert(err.message);}
}
function createFolder() {
  const folder=prompt("Folder name, e.g. images or css/components");
  if(folder===null)return;
  const path=normalizePath(folder);
  if(!path){alert("Enter a folder name.");return;}
  // Filesystem-like folders are represented by paths; a placeholder makes empty folders persist.
  try{addFile(path+"/.webilo-folder","");renderFileTree();toast("Folder created.");}
  catch(err){alert(err.message);}
}
function deleteFile(path) {
  if(path==="index.html"&&projectDoc.files.length===1){alert("Your project needs at least one file.");return;}
  if(!confirm(`Delete ${path}?`))return;
  projectDoc.files=projectDoc.files.filter(f=>f.path!==path&&!f.path.startsWith(path+"/"));
  if(!projectDoc.files.length)projectDoc.files.push({path:"index.html",content:starterHTML});
  if(!projectDoc.files.some(f=>f.path===activePath))activePath=projectDoc.files[0].path;
  selectFile(activePath);markDirty();
}
async function importFiles(event) {
  const files=Array.from(event.target.files||[]);
  if(!files.length)return;
  try {
    for(const file of files) {
      if(file.size>2*1024*1024)throw new Error(`${file.name} is over 2 MB. This demo limits each file to 2 MB.`);
      const content=await readFile(file);
      const path=normalizePath(file.webkitRelativePath||file.name);
      const existing=projectDoc.files.find(f=>f.path===path);
      if(existing)existing.content=content;else projectDoc.files.push({path,content});
    }
    projectDoc.files.sort((a,b)=>a.path.localeCompare(b.path));
    const firstHtml=projectDoc.files.find(f=>f.path.toLowerCase()==="index.html")||projectDoc.files.find(f=>/\.html?$/i.test(f.path));
    if(firstHtml)activePath=firstHtml.path;
    selectFile(activePath);renderFileTree();markDirty();refreshPreview();
    message("editorMessage",`${files.length} file(s) imported. Save to keep them in the cloud.`,"success");
  } catch(err){message("editorMessage",err.message||String(err),"error");}
  finally{event.target.value="";}
}
function readFile(file) {
  if(file.type.startsWith("image/")||/\.(png|jpe?g|webp|gif|ico|woff2?|ttf|otf)$/i.test(file.name)) {
    return new Promise((resolve,reject)=>{
      const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(new Error("Could not read "+file.name));r.readAsDataURL(file);
    });
  }
  return file.text();
}
function showLogo() {
  const img=$("logoPreview"), help=$("logoHelp"), remove=$("removeLogoBtn");
  if(projectDoc.logo){img.src=projectDoc.logo;img.classList.remove("hidden");help.classList.add("hidden");remove.classList.remove("hidden");}
  else{img.removeAttribute("src");img.classList.add("hidden");help.classList.remove("hidden");remove.classList.add("hidden");}
  $("siteFavicon").href=projectDoc.logo||"data:,";
}
async function importLogo(event) {
  const file=event.target.files?.[0];if(!file)return;
  if(file.size>500*1024){message("editorMessage","Logo must be smaller than 500 KB in this demo.","error");event.target.value="";return;}
  try{projectDoc.logo=await readFile(file);showLogo();markDirty();message("editorMessage","Logo added. Save to keep it in your project.","success");}
  catch(err){message("editorMessage",err.message,"error");}
  event.target.value="";
}
function refreshPreview() {
  if(!projectDoc)return;
  const file=currentFile();
  let html=file?.content||"";
  if(!/\.html?$/i.test(activePath)) {
    html=`<!doctype html><html><body style="font-family:system-ui;padding:24px"><h2>${activePath.replace(/[<>&"]/g,"")}</h2><p>Preview is available for HTML files. Edit this file and link it from index.html.</p><pre style="white-space:pre-wrap"></pre></body></html>`;
  }
  const frame=$("sitePreview");
  frame.srcdoc=html;
  $("saveStatus").textContent="Preview refreshed";
}
async function saveProject() {
  if(!session?.user||!currentProject||saving)return;
  const name=$("projectName").value.trim();
  if(!name){message("editorMessage","Please enter a website name.","error");return;}
  const active=currentFile();if(active)active.content=$("fileEditor").value;
  projectDoc.domain=$("domainChoice").value;
  const slug=slugify($("projectSlug").value);
  saving=true;$("saveBtn").disabled=true;$("publishBtn").disabled=true;
  $("saveStatus").textContent="Saving…";message("editorMessage","Saving project and files to Supabase…");
  try {
    const {data,error}=await db.from("webilo_projects").update({
      name,slug,html:JSON.stringify(projectDoc),updated_at:new Date().toISOString()
    }).eq("id",currentProject.id).eq("owner_id",session.user.id)
      .select("id,owner_id,name,slug,html,created_at,updated_at").single();
    if(error)throw error;
    currentProject=data;
    const i=projects.findIndex(p=>p.id===data.id);if(i>=0)projects[i]=data;
    $("editorProjectName").textContent=name;$("projectSlug").value=slug;
    $("saveStatus").textContent="Saved to cloud";renderFileTree();
    message("editorMessage","Project and file contents saved to your Supabase database.","success");
  } catch(err){$("saveStatus").textContent="Save failed";message("editorMessage",errorText(err),"error");}
  finally{saving=false;$("saveBtn").disabled=false;$("publishBtn").disabled=false;}
}
async function deleteProject(id) {
  const p=projects.find(x=>x.id===id);if(!p||!session?.user)return;
  if(!confirm(`Delete "${p.name}" and its saved files permanently?`))return;
  try {
    const {error}=await db.from("webilo_projects").delete().eq("id",id).eq("owner_id",session.user.id);
    if(error)throw error;projects=projects.filter(x=>x.id!==id);renderProjects();toast("Project deleted.");
  } catch(err){message("appMessage",errorText(err),"error");}
}
function openPublishDialog() {
  if(!currentProject)return;
  const slug=slugify($("projectSlug").value||currentProject.slug);
  $("publishSlug").value=slug;$("publishDomain").value=$("domainChoice").value;
  updatePublishUrl();
  if(projectDoc.logo){$("publishLogoPreview").src=projectDoc.logo;$("publishLogoPreview").classList.remove("hidden");$("publishLogoText").textContent="Logo ready";}
  else{$("publishLogoPreview").classList.add("hidden");$("publishLogoText").textContent="No logo uploaded";}
  message("publishMessage","");
  $("publishDialog").showModal();
}
function updatePublishUrl() {
  const slug=slugify($("publishSlug").value);
  $("publishSlug").value=slug;
  $("publishUrl").textContent=`https://${slug}.${$("publishDomain").value}`;
}
async function confirmPublish() {
  projectDoc.published=true;
  projectDoc.publishSlug=slugify($("publishSlug").value);
  projectDoc.domain=$("publishDomain").value;
  $("projectSlug").value=projectDoc.publishSlug;
  $("domainChoice").value=projectDoc.domain;
  await saveProject();
  if($("saveStatus").textContent==="Saved to cloud") {
    $("publishDialog").close();
    toast("Publish details saved. Hosting is not deployed yet.");
    message("editorMessage",`Publish details saved for https://${projectDoc.publishSlug}.${projectDoc.domain}. A deployment backend is still needed to make this URL live.`,"success");
  } else {
    projectDoc.published=false;
    message("publishMessage","Could not save publish details. Fix the error and try again.","error");
  }
}
function bindEvents() {
  $("authForm").addEventListener("submit",submitAuth);
  $("switchAuth").addEventListener("click",()=>setAuthMode(!isSignup));
  $("googleBtn").addEventListener("click",googleSignIn);
  $("logoutBtn").addEventListener("click",logout);
  $("newProjectBtn").addEventListener("click",createProject);
  $("refreshBtn").addEventListener("click",loadProjects);
  $("backBtn").addEventListener("click",async()=>{showOnly("appPage");await loadProjects();});
  $("saveBtn").addEventListener("click",saveProject);
  $("previewBtn").addEventListener("click",()=>{const f=currentFile();if(f)f.content=$("fileEditor").value;refreshPreview();});
  $("newFileBtn").addEventListener("click",createFile);
  $("newFolderBtn").addEventListener("click",createFolder);
  $("importFiles").addEventListener("change",importFiles);
  $("logoInput").addEventListener("change",importLogo);
  $("removeLogoBtn").addEventListener("click",()=>{projectDoc.logo="";showLogo();markDirty();});
  $("fileEditor").addEventListener("input",()=>{const f=currentFile();if(f)f.content=$("fileEditor").value;markDirty();});
  $("projectName").addEventListener("input",()=>{$("editorProjectName").textContent=$("projectName").value||"Untitled website";markDirty();});
  $("projectSlug").addEventListener("input",()=>{markDirty();});
  $("domainChoice").addEventListener("change",()=>{projectDoc.domain=$("domainChoice").value;markDirty();});
  $("publishBtn").addEventListener("click",openPublishDialog);
  $("publishSlug").addEventListener("input",updatePublishUrl);
  $("publishDomain").addEventListener("change",updatePublishUrl);
  $("confirmPublishBtn").addEventListener("click",confirmPublish);
  $("cancelPublishBtn").addEventListener("click",()=>$("publishDialog").close());
}
async function start() {
  bindEvents();setAuthMode(false);
  if(!window.supabase?.createClient){message("authMessage","Supabase library did not load. Check your internet connection and reload.","error");return;}
  try {
    db=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
    const {data,error}=await db.auth.getSession();if(error)throw error;
    session=data.session;
    if(session)await showWorkspace();else showOnly("authPage");
    db.auth.onAuthStateChange((event,newSession)=>{
      session=newSession;
      if(newSession && $("appPage").classList.contains("hidden") && $("editorPage").classList.contains("hidden")) {
        setTimeout(()=>showWorkspace(),0);
      } else if(!newSession) {
        showOnly("authPage");
      }
    });
  } catch(err){showOnly("authPage");message("authMessage",errorText(err),"error");}
}
start();
